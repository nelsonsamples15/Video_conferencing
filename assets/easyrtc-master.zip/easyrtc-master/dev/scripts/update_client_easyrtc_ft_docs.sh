#!/bin/sh
echo "Deprecated use grunt 'grunt jsdoc:client_ft_lite' instead."