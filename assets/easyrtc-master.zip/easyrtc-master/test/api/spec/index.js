/*
  Script: index.js

    This file is part of EasyRTC.
*/
/*global
    define
*/

define([    

    // Load specs
    'spec/api/adapter',
    //'spec/api/easyrtc_int',

], function () {
    'use strict';
});
